# Alles Updaten (Android)

Een eenvoudige Nederlandstalige Android-app met twee knoppen:
- Google Play Store: probeert de pagina met app-updates te openen.
- Samsung Galaxy Store: probeert het UPDATE-tabblad te openen en valt terug op het openen van de winkel.

## Belangrijke beperking
Android staat een gewone app niet toe om updates uit Google Play en Galaxy Store zelfstandig te installeren of beide winkels op afstand te bedienen. De gebruiker rondt updates af in de betreffende winkel.

## APK bouwen
1. Open deze map in Android Studio (Giraffe of nieuwer).
2. Laat Gradle synchroniseren.
3. Kies **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio maakt de APK onder `app/build/outputs/apk/debug/app-debug.apk`.
5. Kopieer die APK naar je Samsung-telefoon, open het bestand en sta installatie vanuit die bron toe als Android daarom vraagt.

Projectinstellingen: minSdk 26 (Android 8.0), targetSdk 35.
