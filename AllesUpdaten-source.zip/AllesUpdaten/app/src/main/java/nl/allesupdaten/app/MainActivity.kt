package nl.allesupdaten.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(0xFFF5F7F5.toInt())
        }

        val title = TextView(this).apply {
            text = "Alles Updaten"
            textSize = 30f
            setTextColor(0xFF123F2D.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val intro = TextView(this).apply {
            text = "Werk je apps bij via beide appwinkels. Android laat apps van andere winkels niet automatisch door één app installeren."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF34433B.toInt())
            setPadding(0, 18, 0, 28)
        }
        root.addView(intro, matchWrap())

        val play = makeButton("1. Updates in Google Play Store") {
            openStore(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://myapps")),
                "com.android.vending",
                "Google Play Store"
            )
        }
        root.addView(play, buttonParams())

        val samsung = makeButton("2. Updates in Galaxy Store") {
            openStore(
                Intent(Intent.ACTION_VIEW, Uri.parse("samsungapps://Main?tab=UPDATE")),
                "com.sec.android.app.samsungapps",
                "Galaxy Store"
            )
        }
        root.addView(samsung, buttonParams())

        val note = TextView(this).apply {
            text = "Tip: tik in elke winkel op ‘Alles bijwerken’ als die optie verschijnt. Soms vraagt de winkel eerst om toestemming."
            textSize = 14f
            setTextColor(0xFF526158.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun openStore(intent: Intent, packageName: String, label: String) {
        intent.setPackage(packageName)
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            try {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                if (launch != null) startActivity(launch)
                else Toast.makeText(this, "$label is niet gevonden op deze telefoon.", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                Toast.makeText(this, "$label kon niet worden geopend.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun buttonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 8, 0, 8) }
}
